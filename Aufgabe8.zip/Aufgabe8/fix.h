#pragma once
#ifdef __INTELLISENSE__
void __syncthreads();
#endif